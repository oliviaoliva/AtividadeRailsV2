class Contact < ApplicationRecord
  belongs_to :store

  # validates :contact_type, presence: true
end
